#include "Encoder.h"

int main()
{
	auto encoder = /* Your encoder type here. */;

	if (!Jwl::Encoder::RunEncoder(encoder))
	{
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
